"use strict";
var Test = (function () {
    function Test(message) {
        this.message = message;
    }
    return Test;
}());
exports.Test = Test;
