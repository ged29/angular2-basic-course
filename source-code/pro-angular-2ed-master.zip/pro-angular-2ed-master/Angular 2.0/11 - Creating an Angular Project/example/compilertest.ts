﻿export class Test {

    constructor(public message: string) { }
}
